<!DOCTYPE html>
<html class="bootstrap-layout">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Dashboard</title>

  <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
  <meta name="robots" content="noindex">

  <!-- Material Design Icons  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <!-- Roboto Web Font -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">

  <!-- App CSS -->
  <link type="text/css" href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet">

  <!-- Charts CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('examples/css/morris.min.css')); ?>">

</head>

<body class="layout-container ls-top-navbar si-l3-md-up breakpoint-1200">

  <!-- Navbar -->
  <nav class="navbar navbar-light bg-white navbar-full navbar-fixed-top ls-left-sidebar">

    <!-- Sidebar toggle -->
    <button class="navbar-toggler pull-xs-left hidden-lg-up active" type="button" data-toggle="sidebar" data-target="#sidebarLeft"><span class="material-icons">menu</span></button>

    <!-- Brand -->
    <a class="navbar-brand first-child-md" href="index.html">Dashboard</a>

    <!-- Search -->
    <form class="form-inline pull-xs-left hidden-sm-down">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for...">
        <span class="input-group-btn"><button class="btn" type="button"><i class="material-icons">search</i></button></span>
      </div>
    </form>
    <!-- // END Search -->

    <!-- Menu -->
    <ul class="nav navbar-nav pull-xs-right hidden-md-down">

      <!-- Notifications dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-caret="false" data-toggle="dropdown" role="button" aria-haspopup="false" aria-expanded="false"><i class="material-icons email">mail_outline</i></a>
        <ul class="dropdown-menu dropdown-menu-right notifications" aria-labelledby="Preview">
          <li class="dropdown-title">Emails</li>
          <li class="dropdown-item email-item">
            <a class="nav-link" href="index.html">
              <span class="media">
					<span class="media-left media-middle"><i class="material-icons">mail</i></span>
              <span class="media-body media-middle">
						<small class="pull-xs-right text-muted">12:20</small>
						<strong>Adrian Demian</strong>
						Enhance your website with
					</span>
              </span>
            </a>
          </li>
          <li class="dropdown-item email-item">
            <a class="nav-link" href="index.html">
              <span class="media">
					<span class="media-left media-middle">
						<i class="material-icons">mail</i>
					</span>
              <span class="media-body media-middle">
						<small class="text-muted pull-xs-right">30 min</small>
						<strong>Michael Brain</strong>
						Partnership proposal
					</span>
              </span>
            </a>
          </li>
          <li class="dropdown-item email-item">
            <a class="nav-link" href="index.html">
              <span class="media">
					<span class="media-left media-middle">
						<i class="material-icons">mail</i>
					</span>
              <span class="media-body media-middle">
						<small class="text-muted pull-xs-right">1 hr</small>
						<strong>Sammie Downey</strong>
						UI Design
					</span>
              </span>
            </a>
          </li>
          <li class="dropdown-action center">
            <a href="email.html">Go to inbox</a>
          </li>
        </ul>
      </li>
      <!-- // END Notifications dropdown -->

      <!-- User dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link active dropdown-toggle p-a-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
          <img src="<?php echo e(asset('assets/images/people/50/guy-6.jpg')); ?>" alt="Avatar" class="img-circle" width="40">
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-list" aria-labelledby="Preview">
          <a class="dropdown-item" href="#"><i class="material-icons md-18">lock</i> <span class="icon-text">Edit Account</span></a>
          <a class="dropdown-item" href="#"><i class="material-icons md-18">person</i> <span class="icon-text">Public Profile</span></a>
          <a class="dropdown-item" href="#">Logout</a>
        </div>
      </li>
      <!-- // END User dropdown -->

    </ul>
    <!-- // END Menu -->

  </nav>
  <!-- // END Navbar -->

  <!-- Sidebar -->
  <div class="sidebar sidebar-left si-si-3 sidebar-visible-md-up sidebar-dark bg-primary simplebar sidebar-visible" id="sidebarLeft" data-scrollable=""><div class="simplebar-track" style="display: none;"><div class="simplebar-scrollbar" style="top: 2px; height: 362px;"></div></div><div class="simplebar-scroll-content"><div class="simplebar-content">

    <!-- Brand -->
    <a href="index.html" class="sidebar-brand">
      <i class="material-icons">control_point</i>DBM</a>

    <!-- User -->
    <a href="user-profile.html" class="sidebar-link sidebar-user">
      <img src="<?php echo e(asset('assets/images/people/110/guy-6.jpg')); ?>" alt="user" class="img-circle">Administrador</a>
    <!-- // END User -->

    <!-- Menu -->
    <ul class="sidebar-menu sm-bordered sm-active-button-bg">
      <li class="sidebar-menu-item active">
        <a class="sidebar-menu-button" href="index.html">
          <i class="sidebar-menu-icon material-icons">home</i> Dashboard
        </a>
      </li>

      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="ui-elements.html">
          <i class="sidebar-menu-icon material-icons">tune</i>CONFIGURAÇÕES</a>
        <ul class="sidebar-submenu">
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="ui-buttons.html">Cursos a Venda</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="ui-cards.html">MailChimp</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="ui-tabs.html">PagSeguro</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="ui-tree.html">Rodapé</a>
          </li>









        </ul>
      </li>
      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">
          <i class="sidebar-menu-icon material-icons">assignment</i> <span>Páginas</span>
        </a>
        <ul class="sidebar-submenu">
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="appointments.html">Home</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="chat.html">O Curso</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="invoice.html">Profissionais</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="learning-dashboard.html">DBMicos</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="learning-course.html">Galeria</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="notes.html">Contatos</a>
          </li>







        </ul>
      </li>
    </ul>
    <!-- // END Menu -->

    <!-- Activity -->


    <!-- // END Activity -->

    <!-- Stats -->
    <div class="sidebar-stats">
      <div class="sidebar-stats-lead text-primary">
        <span>410</span>
        <small class="text-success">
          <i class="material-icons md-middle">arrow_upward</i>

        </small>
      </div>
      <small>TOTAL PEDIDOS</small>
    </div>
    <!-- // END Stats -->

  </div></div></div>
  <!-- // END Sidebar -->

  <!-- Right Sidebars -->

  <!-- Content -->
  <div class="layout-content simplebar" data-scrollable=""><div class="simplebar-track" style="display: none;"><div class="simplebar-scrollbar" style="top: 90px; height: 298px;"></div></div><div class="simplebar-scroll-content"><div class="simplebar-content">
    <div class="container-fluid">

      <!-- Breadcrumb -->


      <!-- Row -->
      <div class="row">

        <!-- Column -->
        <div class="col-md-8">

          <div class="card">
            <ul class="nav nav-tabs">
              <li class="nav-item">
                <a class="nav-link" id="history-tab" data-toggle="tab" href="#history" aria-expanded="false">
                  <i class="material-icons">schedule</i> <span class="icon-text">Histórico</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" id="customers-tab" data-toggle="tab" href="#customers" aria-expanded="true">
                  <i class="material-icons">person_add</i> <span class="icon-text">Sign Ups</span>
                </a>
              </li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane fade" id="history" aria-expanded="false">
                <ul class="list-group list-group-fit">
                  <li class="list-group-item">
                    <div class="media">
                      <div class="media-left media-middle">
                        <i class="material-icons md-36 text-muted">receipt</i>
                      </div>
                      <div class="media-body">
                        <p class="m-a-0">
                          <a href="#">Sam</a> added a new invoice <a href="#">#9591</a>
                        </p>
                        <small class="text-muted">
                          <i class="material-icons md-18">timer</i> <span class="icon-text">5 hrs ago</span>
                        </small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item">
                    <div class="media">
                      <div class="media-left media-middle">
                        <i class="material-icons md-36 text-muted">dns</i>
                      </div>
                      <div class="media-body">
                        <p class="m-a-0">
                          <a href="#">John</a> created a new <a href="#">task</a>
                        </p>
                        <small class="text-muted">
                          <i class="material-icons md-18">today</i> <span class="icon-text">1 day ago</span>
                        </small>
                      </div>
                    </div>
                  </li>
                  <li class="list-group-item">
                    <div class="media">
                      <div class="media-left media-middle">
                        <i class="material-icons md-36 text-muted">group</i>
                      </div>
                      <div class="media-body">
                        <p class="m-a-0">
                          <a href="#">Partick</a> added <a href="#">Sam</a> are now friends.
                        </p>
                        <small class="text-muted">
                          <i class="material-icons md-18">today</i> <span class="icon-text">2 days ago</span>
                        </small>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div class="tab-pane active in" id="customers" aria-expanded="true">
                <table class="table  m-b-0">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Company</th>
                      <th width="120" class="center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><a href="#"> Derek S.</a></td>
                      <td>Reel Ltd.</td>
                      <td class="text-xs-center">
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">edit</i>
                        </a>
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">email</i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td><a href="#"> Paul M.</a></td>
                      <td>Places Ltd.</td>
                      <td class="text-xs-center">
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">edit</i>
                        </a>
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">email</i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td><a href="#"> John D.</a></td>
                      <td>Woot Ltd.</td>
                      <td class="text-xs-center">
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">edit</i>
                        </a>
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">email</i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td><a href="#">Amy T.</a></td>
                      <td>Scoop Ltd.</td>
                      <td class="text-xs-center">
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">edit</i>
                        </a>
                        <a href="#" class="btn btn-white btn-sm">
                          <i class="material-icons md-18">email</i>
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- // END Column -->

        <!-- Column -->

        <!-- // END Column -->

        <!-- Column -->
        <div class="col-md-4">
          <div class="card">
            <div class="card-header bg-white center">
              <h5 class="card-title">Top Member</h5>
              <p class="card-subtitle m-b-0">Adrian Demian</p>
            </div>
            <table class="table table-sm m-b-0">
              <tbody><tr>
                <td><i class="material-icons text-primary">person</i> <span class="icon-text"><a href="#">Adrian Demian</a></span></td>
                <td class="right">
                  <div class="label label-success">49</div>
                </td>
                <td class="right" width="1"><a href="#" class="btn btn-xs btn-white"><i class="material-icons md-18">chevron_right</i></a></td>
              </tr>
              <tr>
                <td class="text-muted"><i class="material-icons text-muted">person</i> <span class="icon-text">Michelle Smith</span></td>
                <td class="right">
                  <div class="label label-default">24</div>
                </td>
                <td class="right" width="1"><a href="#" class="btn btn-xs btn-white"><i class="material-icons md-18">chevron_right</i></a></td>
              </tr>

              <tr>
                <td class="text-muted"><i class="material-icons text-muted">person</i> <span class="icon-text">Jonny Clint</span></td>
                <td class="right">
                  <div class="label label-default">16</div>
                </td>
                <td class="right" width="1"><a href="#" class="btn btn-xs btn-white"><i class="material-icons md-18">chevron_right</i></a></td>
              </tr>
              <tr>
                <td class="text-muted"><i class="material-icons text-muted">person</i> <span class="icon-text">Andrew Brain</span></td>
                <td class="right">
                  <div class="label label-default">13</div>
                </td>
                <td class="right" width="1"><a href="#" class="btn btn-xs btn-white"><i class="material-icons md-18">chevron_right</i></a></td>
              </tr>
              <tr>
                <td class="text-muted"><i class="material-icons text-muted">person</i> <span class="icon-text">Bill Carter</span></td>
                <td class="right">
                  <div class="label label-default">5</div>
                </td>
                <td class="right"><a href="#" class="btn btn-xs btn-white"><i class="material-icons md-18">chevron_right</i></a></td>
              </tr>
            </tbody></table>
          </div>
        </div>
        <!-- // END Column -->

      </div>
      <!-- // END Row -->

      <!-- Row -->





      <!-- // END Row -->

    </div>
  </div></div></div>

  <!-- jQuery -->
  <script src="<?php echo e(asset('assets/vendor/jquery.min.js')); ?>"></script>

  <!-- Bootstrap -->
  <script src="<?php echo e(asset('assets/vendor/tether.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap.min.js')); ?>"></script>

  <!-- AdminPlus -->
  <script src="<?php echo e(asset('assets/vendor/adminplus.js')); ?>"></script>

  <!-- App JS -->
  <script src="<?php echo e(asset('assets/js/main.min.js')); ?>"></script>

  <!-- Theme Colors -->
  <script src="<?php echo e(asset('assets/js/colors.js')); ?>"></script>

  <!-- Charts JS -->
  <script src="<?php echo e(asset('assets/vendor/raphael.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/morris.min.js')); ?>"></script>

  <!-- Initialize Charts -->
  <script src="<?php echo e(asset('examples/js/chart.js')); ?>"></script>



</body>

</html>

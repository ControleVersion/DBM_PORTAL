<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar Banner </h1>

   <?php echo Form::model($banner, [ 'method' => 'PUT','files'=>true,  'class'=>'form-horizontal','route' => ['banner.update', $banner->id ]]); ?>



       <fieldset class="form-group">
           <label for="Imagem_Destaque">Imagem destaque</label>
           <br>
           <img src="<?php echo e(asset('/').'/'.$banner->url_imagem); ?>" class="img-responsive" alt="Img Banner" style="min-width: 436px !important; max-width: 436px !important;"/>
           <p class="errors"><?php echo $errors->first('image'); ?></p>
             <?php if(Session::has('error')): ?>
                 <p class="errors"><?php echo Session::get('error'); ?></p>
             <?php endif; ?>
         <?php echo Form::file('image', null,['class'=>'form-control-file', 'id'=>'upload']); ?>

         <small class="text-help">Imagem no tamanho 1296x546 menor que 500kb.</small>
       </fieldset>

       <fieldset class="form-group">
         <label for="titulo">Titulo Destaque</label>

         <?php echo Form::text('titulo_destaque',null, ['class'=>'form-control', 'id'=>'titulo_destaque',  "placeholder"=>"Titulo"]); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="exampleSelect1">Sub Título</label>

         <?php echo Form::text('subtitulo',null, ['class'=>'form-control', 'id'=>'subtitulo',  "placeholder"=>"Subtitulo"]); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Texto Link</label>

         <?php echo Form::text('texto_link',null, ['class'=>'form-control', 'id'=>'texto_link',  "placeholder"=>"Texto Link"]); ?>

       </fieldset>
       <fieldset class="form-group">
         <label for="exampleTextarea">Link do Botão</label>

         <?php echo Form::text('link_botao',null, ['class'=>'form-control', 'id'=>'link_botao',  "placeholder"=>"Link botão"]); ?>

       </fieldset>


       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/list')); ?>" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
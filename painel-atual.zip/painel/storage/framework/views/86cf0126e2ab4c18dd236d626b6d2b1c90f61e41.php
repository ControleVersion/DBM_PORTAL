<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-sm-12 col-md-12 col-md-offset-1" style="margin-bottom: 400px;">
   <h3> Convidar Alunos Presenciais em Lote</h3>

   <div class="col-sm-6 col-md-6" id="cadastrar-sobre">
     <div class="card">
       <div class="card-block">
         <h5>Convidar Novos</h5>

       <?php echo Form::open(['route'=>'convidar.store','method'=>'post', 'class'=>'form-horizontal']); ?>

		<!--
       <fieldset class="form-group">
           <label for="Email_Convite">Nome do aluno</label>

         <?php echo Form::text('name', null,['class'=>'form-control','required'=>"", 'id'=>'email']); ?>


       </fieldset>
       -->

         <fieldset class="form-group">
             <label for="Email_Convite">Alunos cadastrados na Lista <br> (Recomenda-se testar a validade dos emails antes de disparar)
             	<br>Selecione grupos de 50 em 50, segurando a tecla CTRL do seu teclado, 
             	<br>envios de lotes de convites acima de 50 pode sobrecarregar o servidor e entrar em BlackList. 
             </label>

           
           	<select style="height: 300px;" multiple name="email[]" class="form-control" id="sel2">
        		<?php foreach($listadealunos as $alunos): ?>
        			<?php if($alunos->status == "Pendente"): ?>
        				<option style="color:red !important;" value="<?php echo e($alunos->id); ?>"><?php echo e($alunos->nome); ?> - [<?php echo e($alunos->email); ?>] 
        				[<?php echo e($alunos->status); ?>] </option>
        			<?php else: ?>
        				<option style="color:green !important;" value="<?php echo e($alunos->id); ?>"><?php echo e($alunos->nome); ?> - [<?php echo e($alunos->email); ?>] 
        				[<?php echo e($alunos->status); ?>] </option>
        			<?php endif; ?>
        		<?php endforeach; ?>
      		</select>

         </fieldset>
         


         <?php echo Form::submit( 'ENVIAR', array('class'=>'btn btn-primary')); ?>

         <?php echo Form::close(); ?>

       </div>
     </div>
   </div>
   <!-- ============ FIM DO convidar ===== -->


 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<meta charset="utf-8">
<table align="center" border="0" cellpadding="0" cellspacing="0" width="700px" style="border-collapse: collapse; font-family: Helvetica,Arial,sans-serif;box-shadow:1px 1px 5px #ccc">
	<tr>
		<td bgcolor="#1e72b9" height="100px" style="padding-left:20px;"">
		<a href="<?php echo e(asset('/')); ?>">
		<img src="<?php echo e(asset('/')); ?>site/images/DBM-logo-white.png" width="140" height="70" alt="DBM logo"></a>
			
		</td>
	</tr>
	<tr bgcolor="#fff">
		<td style="padding-top:40px; padding-bottom:40px; padding-left:20px;">
			<h2 style="font-size:30px; padding-bottom:10px;">Oi <span style="color:#039be5;"><?php echo e($Nome); ?></span>, muito obrigado pela sua participação no evento DBM presencial.</h2>
			<br>
			<p style="font-size:20px; color:#000">Ficamos muito felizes com a sua presença e já estamos com saudade.</p>
			<br>
			<span style="color:#000">Por isso, disponibilizaremos para você acesso as palestras do evento no nosso site. Clique no link abaixo, cadastre-se e aproveite!!!</span>
			<br>
			
			<a href="<?php echo e(asset('/')); ?>registro?access=presencial#undefined2" id="btnConDBM2017" style="display:block;margin-top:20px;padding:20px; background-color:#039BE5; width:200px;border-radius:10px; text-align: center; color:#fff; font-weight:bold; text-decoration:none;">CADASTRAR</a>
		</td>
	</tr>
	<tr>
		<td bgcolor="#1e72b9" height="45px" style="padding-left:20px; font-size:12px;text-align:center;">
			<p  style="color:#ffffff;"">Você recebeu este e-mail porque participou no evento DBM presencial <a href="<?php echo e(asset('/')); ?>" style="color:#ccc; text-decoration:none;">portalDBM.com.br</a>
			<br>	
			Caso não tenha participado do evento desconsidere essa mensagem.</p>
		</td>
	</tr>
</table>

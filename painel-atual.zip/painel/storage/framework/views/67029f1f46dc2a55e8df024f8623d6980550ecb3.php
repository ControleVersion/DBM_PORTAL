<?php $__env->startSection('content'); ?>
<div class="row">

  <?php if(!Auth::guest()): ?>
    <?php if($aluno[0]->plano_acesso == "Presencial"): ?>
       <!-- Column -->
       <!-- estrutura básica video -->
       <?php foreach($videoaulas as $video): ?>
       <section class="col-md-4 video-post">
         <div class="card">
           <div class="card-block">
             <div class="media">
               <div class="media-left media-middle">
                 <!-- avatar do professor que deu a aula -->
                 <img src="<?php echo e(asset('site/images/person_perfil.png')); ?>" alt="" class="img-circle" width="50">
               </div>
               <div class="media-body media-middle">
                 <p class="card-subtitle"><?php echo e($video->nome); ?></p>
                 <small>Data: <?php echo e(date('d/m/Y', strtotime($video->created_at))); ?></small>
               </div>
             </div>
           </div>
           <a href="<?php echo e(asset('area-aluno/videos/ver')); ?>/<?php echo e($video->id_youtube); ?>">
             <img src="<?php echo e(asset('/')); ?>/<?php echo e($video->miniatura); ?>" alt="" width="100%">
           </a>
           <div class="card-block">
             <h4 class="card-title"> <?php echo e($video->tema); ?> </h4>
             <!-- <p>Nesta aula vamos falar sobre...</p> -->
           </div>
         </section>
        <?php endforeach; ?>
         <!-- estrutura básica video -->

       <!-- // END Column -->
    <?php else: ?>
      <div class="alert alert-info text-center" role="alert">
        Você ainda não possui um dos nossos cursos e treinamentos exclusivos? Aproveite agora mesmo e adiquira um <a href="<?php echo e(asset('/comprar')); ?>" class="alert-link">CLIQUE AQUI</a>.
      </div>
    <?php endif; ?>
  <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site.area-aluno.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<table class="table table-bordered">
   <tr>
       <th>Titulo</th>
       <th>Imagem</th>
   </tr>
   <?php foreach($products as $product): ?>
   <tr>
       <td><?php echo e($product->titulo_destaque); ?></td>
       <td><?php echo e($product->imagem_destaque); ?></td>
   </tr>
   <?php endforeach; ?>
</table>
   <?php echo $products->links(); ?>


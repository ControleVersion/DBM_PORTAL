<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar Video Degustação </h1>

   <?php echo Form::model($degustacao, [ 'method' => 'PUT','files'=>true,  'class'=>'form-horizontal','route' => ['degustacao.update', $degustacao->id ]]); ?>




       <fieldset class="form-group">
           <label for="Descricao"> Sub Título </label>

         <?php echo Form::text('subtitulo', null,['class'=>'form-control','required'=>"", 'id'=>'subtitulo']); ?>


       </fieldset>

       <fieldset class="form-group">
           <label for="Descricao"> Descrição Curta </label>

         <?php echo Form::text('descricao_curta', null,['class'=>'form-control','required'=>"", 'id'=>'descricao_curta']); ?>


       </fieldset>


       <fieldset class="form-group">
         <label for="exampleSelect1">Imagem destaque do vídeo</label>
         <br>
         <label class="file">

           <?php echo Form::file('image',null, ['class'=>'form-control', 'required'=>"", 'id'=>'file']); ?>

           <span class="file-custom"></span>
         </label>

       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Link</label>

         <?php echo Form::text('link_externo',null, ['class'=>'form-control', 'id'=>'url_externa',  "placeholder"=>"Link"]); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Professor</label>
         <br>
         <select class="c-select" id="professor_id" name="professor_id">
             <?php foreach($professors as $professor): ?>

             <option value="<?php echo e($professor->id); ?>" <?php echo ($degustacao->professor_id == $professor->id)?'selected' :'';?>><?php echo e($professor->nome); ?></option>
             <?php endforeach; ?>
         </select>
       </fieldset>

       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/list')); ?>" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
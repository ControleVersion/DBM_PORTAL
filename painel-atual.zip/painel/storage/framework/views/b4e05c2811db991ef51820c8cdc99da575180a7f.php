<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar</h1>

   <?php echo Form::model($dbmcurso, [ 'method' => 'PUT',  'class'=>'form-horizontal','route' => ['profissionais.update', $dbmcurso->id ]]); ?>




       <fieldset class="form-group">
           <label for="Descricao"> ID do Video Youtube </label>

         <?php echo Form::text('video_id', null,['class'=>'form-control','required'=>"", 'id'=>'video_id']); ?>


       </fieldset>


       <fieldset class="form-group">
         <label for="texto_link"> Titulo </label>

         <?php echo Form::text('titulo',null, ['class'=>'form-control', 'id'=>'formacao']); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="descricao">Descrição curta</label>

         <?php echo Form::textarea('descricao',null, ['class'=>'form-control', 'id'=>'descricao']); ?>

       </fieldset>




       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/dbmcurso')); ?>" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="simplebar-scroll-content">
  <div class="simplebar-content">
    <div class="container-fluid">



          <div class="tab-content p-a-1 m-b-1"  style="margin-left: 50px;display: inline-block; width: 80%;">

            <div class="tab-pane  active" id="one" aria-expanded="false">

              <h5>Lista de usuários de sistema</h5>

              <hr>

              <!-- ===== LISTAR ==================== -->
              <div class="card" id="listar-banners">
                <div class="card-header">Usuários Cadastrados</div>
                <table class="table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>email</th>
						<th>Tipo</th>
                      <th>Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $x=0;?>
                    <?php foreach($users as $user): ?>

                    <tr class="<?php echo ($x == 0)?  'table-active': '';?>">
                      <th scope="row"><?php echo e($user->id); ?></th>
                      <td><?php echo e($user->name); ?></td>
                      <td><?php echo e($user->email); ?></td>
                      <td><?php echo e(($user->type == "admin")?"Administrador": "Aluno"); ?></td>
                      <td>
                      	<?php if($user->type != "admin"): ?>
                        <button onclick="javascript:window.location.href='<?php echo e(asset('adm/users/view/')); ?>/<?php echo e($user->id); ?>'" type="button" class="btn btn-white btn-sm">
                          <i class="material-icons">edit</i>
                          <span class="icon-text"></span>
                        </button>
                        <?php endif; ?>


                      </td>
                    </tr>
                    <?php $x++?>
                    <?php endforeach; ?>


                  </tbody>
                </table>

                <!-- PAGINACAO DOS BANNERS -->


                <div class="col-sm-7">
                  <div class="dataTables_paginate paging_simple_numbers" id="datatable-example_paginate">
                    <ul class="pagination">
                        <li class="paginate_button <?php echo e(($users->currentPage() == 1) ? ' disabled' : ''); ?>">
                            <a href="<?php echo e($users->url(1)); ?>">Anterior</a>
                        </li>
                        <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                            <li class="paginate_button <?php echo e(($users->currentPage() == $i) ? ' active' : ''); ?>">
                                <a href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="paginate_button <?php echo e(($users->currentPage() == $users->lastPage()) ? ' disabled' : ''); ?>">
                            <a href="<?php echo e($users->url($users->currentPage()+1)); ?>" >Próximo</a>
                        </li>
                    </ul>
                  </div>
                </div>

              </div>
              <!-- ===== FIM LISTAR ================ -->


            </div>


            </div>
        </div>
      </div>

      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<h3>Redefinição de Senha</h3>
<p>Você acaba de solicitar a redefinição de sua senha em nosso portal.  Segue abaixo o link para fazê-lo:</p>
<br>

Clique no link para cadastrar uma nova senha no sistema:<br> <a href="<?php echo e($link = url('password/reset', $token).'?email='.urlencode($user->getEmailForPasswordReset())); ?>"> <?php echo e($link); ?> </a>

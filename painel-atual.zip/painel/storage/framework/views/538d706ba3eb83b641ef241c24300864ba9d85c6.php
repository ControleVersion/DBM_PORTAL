<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar DBM Número </h1>

   <?php echo Form::model($dbmnumero, [ 'method' => 'PUT','files'=>true,  'class'=>'form-horizontal','route' => ['dbmnumeros.update', $dbmnumero->id ]]); ?>




       <fieldset class="form-group">
           <label for="Descricao"> Icone</label>

         <?php echo Form::text('icone', null,['class'=>'form-control','required'=>"", 'id'=>'icone']); ?>


       </fieldset>

       <fieldset class="form-group">
           <label for="Descricao"> Numero </label>

         <?php echo Form::number('numero', null,['class'=>'form-control','required'=>"", 'id'=>'numero']); ?>


       </fieldset>



       <fieldset class="form-group">
         <label for="texto_link">Subtitulo</label>

         <?php echo Form::text('subtitulo',null, ['class'=>'form-control', 'id'=>'subtitulo']); ?>

       </fieldset>


       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/list')); ?>#four" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
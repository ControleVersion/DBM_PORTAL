<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar foto da galeria </h1>

   <?php echo Form::model($galeria, [ 'method' => 'PUT','files'=>true,  'class'=>'form-horizontal','route' => ['galerias.update', $galeria->id ]]); ?>




       <fieldset class="form-group">
           <label for="Descricao"> Título </label>

         <?php echo Form::text('titulo', null,['class'=>'form-control','required'=>"", 'id'=>'titulo']); ?>


       </fieldset>

       <fieldset class="form-group">
           <label for="Descricao"> Miniatura </label>
           <br>
         <img src="<?php echo e(url('/').'/'.$galeria->url_thumb); ?>" alt="Miniatura" width="300" />
         <?php echo Form::file('image', ['class'=>'form-control-file', 'id'=>'upload']); ?>

         <small class="text-help">Imagem no tamanho 370x370 menor que 250kb.</small>
       </fieldset>



       <fieldset class="form-group">
         <label for="texto_link">Imagem destaque</label>
         <br>
         <img src="<?php echo e(url('/').'/'.$galeria->url_imagem); ?>" alt="Destaque"  width="300" />
         <?php echo Form::file('image2', ['class'=>'form-control-file', 'id'=>'upload2']); ?>

         <small class="text-help">Imagem no tamanho 1200x800 menor que 250kb.</small>
       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Descricao curta</label>

         <?php echo Form::textarea('descricao_curta',null, ['class'=>'form-control', 'id'=>'descricao_curta']); ?>

       </fieldset>



       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/galerias')); ?>" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php
	/*
		administrar PDFs do Menu administrativo
	*/
?>


<?php $__env->startSection('content'); ?>
<div class="col-md-12">

        <?php if(Session::has('success')): ?>
          <div class="alert-box success">
          <h2><?php echo Session::get('success'); ?></h2>
          </div>
        <?php endif; ?>

			<?php echo Form::open(['route'=>'apply.upload','method'=>'post','files'=>true, 'class'=>'form-horizontal']); ?>




					<!-- <input type="file" class="form-control-file" name="imagem_destaque" id="imagem_destaque"> -->

				<fieldset class="form-group">
						<label for="Imagem_Destaque">Imagem destaque</label>
			  		<p class="errors"><?php echo $errors->first('image'); ?></p>
							<?php if(Session::has('error')): ?>
									<p class="errors"><?php echo Session::get('error'); ?></p>
							<?php endif; ?>
	      	<?php echo Form::file('image', ['class'=>'form-control-file', 'id'=>'upload']); ?>

					<small class="text-help">Imagem no tamanho 1296x546 menor que 500kb.</small>
				</fieldset>

				<fieldset class="form-group">
					<label for="titulo">Titulo Destaque</label>

					<?php echo Form::text('titulo_destaque',null, ['class'=>'form-control', 'id'=>'titulo_destaque',  "placeholder"=>"Titulo"]); ?>

				</fieldset>

				<fieldset class="form-group">
					<label for="exampleSelect1">Sub Título</label>

					<?php echo Form::text('subtitulo',null, ['class'=>'form-control', 'id'=>'subtitulo',  "placeholder"=>"Subtitulo"]); ?>

				</fieldset>

				<fieldset class="form-group">
					<label for="texto_link">Texto Link</label>

					<?php echo Form::text('texto_link',null, ['class'=>'form-control', 'id'=>'texto_link',  "placeholder"=>"Texto Link"]); ?>

				</fieldset>
				<fieldset class="form-group">
					<label for="exampleTextarea">Link do Botão</label>
					
					<?php echo Form::text('link_botao',null, ['class'=>'form-control', 'id'=>'link_botao',  "placeholder"=>"Link botão"]); ?>

				</fieldset>


				<?php echo Form::submit( 'CADASTRAR', array('class'=>'btn btn-primary')); ?>

	      <?php echo Form::close(); ?>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
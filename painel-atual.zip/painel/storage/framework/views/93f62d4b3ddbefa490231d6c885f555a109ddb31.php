<!DOCTYPE html>
<html class="bootstrap-layout">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Dashboard</title>

  <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
  <meta name="robots" content="noindex">

  <!-- Material Design Icons  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <!-- Roboto Web Font -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">

  <!-- App CSS -->
  <link type="text/css" href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet">

  <!-- Charts CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('site/css/morris.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.css')); ?>">

</head>

<body class="layout-container ls-top-navbar si-l3-md-up breakpoint-1200">

  <!-- Navbar -->
  <nav class="navbar navbar-light bg-white navbar-full navbar-fixed-top ls-left-sidebar">

    <!-- Sidebar toggle -->
    <button class="navbar-toggler pull-xs-left hidden-lg-up active" type="button" data-toggle="sidebar" data-target="#sidebarLeft"><span class="material-icons">menu</span></button>

    <!-- Brand -->
    <a class="navbar-brand first-child-md" href="<?php echo e(asset('adm/dashboard')); ?>">Dashboard</a>

    <!-- Search -->
    <!--
    <form class="form-inline pull-xs-left hidden-sm-down">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for...">
        <span class="input-group-btn"><button class="btn" type="button"><i class="material-icons">search</i></button></span>
      </div>
    </form>
    -->
    <!-- // END Search -->

    <!-- Menu -->
    <ul class="nav navbar-nav pull-xs-right hidden-md-down">

      <!-- User dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link active dropdown-toggle p-a-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
          <img src="<?php echo e(asset('site/images/person_perfil.png')); ?>" alt="Avatar" class="img-circle" width="40">
        </a>
        <?php if(!Auth::guest()): ?>
          <div class="dropdown-menu dropdown-menu-right dropdown-menu-list" aria-labelledby="Preview">
            <a class="dropdown-item" href="<?php echo e(asset('adm/perfil/')); ?>/<?php echo e(Auth::user()->id); ?>">
              <i class="material-icons md-18">lock</i>
              <span class="icon-text">Editar Dados Pessoais</span>
            </a>

            <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Logout</a>
          </div>
        <?php endif; ?>
      </li>
      <!-- // END User dropdown -->

    </ul>
    <!-- // END Menu -->

  </nav>
  <!-- // END Navbar -->

  <!-- Sidebar -->
  <div class="sidebar sidebar-left si-si-3 sidebar-visible-md-up sidebar-dark bg-primary simplebar sidebar-visible" id="sidebarLeft" data-scrollable=""><div class="simplebar-track" style="display: none;"><div class="simplebar-scrollbar" style="top: 2px; height: 362px;"></div></div><div class="simplebar-scroll-content"><div class="simplebar-content">

    <!-- Brand -->
    <a href="<?php echo e(asset('adm/dashboard')); ?>" class="sidebar-brand">
      <i class="material-icons">control_point</i>DBM</a>

    <!-- User -->
    <a href="#user-profile.html" class="sidebar-link sidebar-user">
      <?php if(!Auth::guest()): ?>
        <img src="<?php echo e(asset('site/images/person_perfil.png')); ?>" alt="user" class="img-circle"><?php echo e(Auth::user()->name); ?></a>

        <?php if(Auth::user()->type == "default"): ?>
          <?php
            //EVITANDO QUE USUARIO DO TIPO ASSINANTE OU FREE TENHA ACESSO AO ADMINISTRADOR
            header('Location: '.asset('/area-aluno'));
            exit();
            ?>
        <?php endif; ?>

      <?php endif; ?>
    <!-- // END User -->

    <!-- Menu -->
    <ul class="sidebar-menu sm-bordered sm-active-button-bg">
      <li class="sidebar-menu-item active">
        <a class="sidebar-menu-button" href="<?php echo e(asset('adm/dashboard')); ?>">
          <i class="sidebar-menu-icon material-icons">home</i> Dashboard
        </a>
      </li>

      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#ui-elements.html">
          <i class="sidebar-menu-icon material-icons">tune</i>CONFIGURAÇÕES</a>
        <ul class="sidebar-submenu">
          <!--
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="#ui-buttons.html">Cursos a Venda</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="#ui-cards.html">MailChimp</a>
          </li>
          -->
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(url('adm/pagseguro/list')); ?>">PagSeguro</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="#ui-tree.html">Rodapé</a>
          </li>
        </ul>
      </li>

      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">
          <i class="sidebar-menu-icon material-icons">assignment</i> <span>Páginas</span>
        </a>
        <ul class="sidebar-submenu">
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(asset('adm/homepage')); ?>">Home</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(asset('adm/dbmcurso')); ?>">O Curso</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(asset('adm/profissionais')); ?>">Profissionais</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="#learning-dashboard.html">DBMicos</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(asset('adm/galerias')); ?>">Galeria</a>
          </li>
          <li class="sidebar-menu-item">
            <a class="sidebar-menu-button" href="<?php echo e(asset('adm/contatos')); ?>">Contatos</a>
          </li>

        </ul>
      </li>

      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">
          <i class="material-icons">important_devices</i> Vídeos Aulas
        </a>
        <ul class="sidebar-submenu">
            <li class="sidebar-menu-item">
              <a class="sidebar-menu-button" href="<?php echo e(asset('adm/videoaulas/listar')); ?>">Listar Todas</a>
            </li>
            <li class="sidebar-menu-item">
              <a class="sidebar-menu-button" href="<?php echo e(asset('adm/professors')); ?>">Professores</a>
            </li>
            <li class="sidebar-menu-item">
              <a class="sidebar-menu-button" href="<?php echo e(asset('adm/categories')); ?>">Categorias</a>
            </li>
            <li class="sidebar-menu-item">
              <a class="sidebar-menu-button" href="<?php echo e(asset('adm/reviews/listar')); ?>">Avaliações de Aluno</a>
            </li>
        </ul>
      </li>

      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">
          <i class="material-icons">supervisor_account</i> Administrar Usuários
        </a>
        <ul class="sidebar-submenu">
            <li class="sidebar-menu-item">
              <a class="sidebar-menu-button" href="<?php echo e(asset('adm/users')); ?>">Listar Todos</a>
            </li>

        </ul>
      </li>

    </ul>
    <!-- // END Menu -->

    <!-- Activity -->


    <!-- // END Activity -->

    <!-- Stats -->
    <div class="sidebar-stats">
      <div class="sidebar-stats-lead text-primary">
        <span>0</span>
        <small class="text-success">
          <i class="material-icons md-middle">arrow_upward</i>

        </small>
      </div>
      <small>TOTAL PEDIDOS</small>
    </div>
    <!-- // END Stats -->

  </div>
</div>
</div>
  <!-- // END Sidebar -->

  <!-- Right Sidebars -->

  <!-- Content -->
  <div class="layout-content simplebar" data-scrollable="">
      <div class="simplebar-track" style="display: none;">
        <div class="simplebar-scrollbar" style="top: 90px; height: 298px;">
        </div>
      </div>

      <div class="simplebar-scroll-content">
          <div class="simplebar-content">

            <?php echo $__env->yieldContent('content'); ?>

          </div>
      </div>
  </div>

  <!-- jQuery -->
  <script src="<?php echo e(asset('assets/vendor/jquery.min.js')); ?>"></script>

  <!-- Bootstrap -->
  <script src="<?php echo e(asset('assets/vendor/tether.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/bootstrap.min.js')); ?>"></script>

  <!-- AdminPlus -->
  <script src="<?php echo e(asset('assets/vendor/adminplus.js')); ?>"></script>

  <!-- App JS -->
  <script src="<?php echo e(asset('assets/js/main.min.js')); ?>"></script>

  <!-- Theme Colors -->
  <script src="<?php echo e(asset('assets/js/colors.js')); ?>"></script>

  <!-- Charts JS -->
  <script src="<?php echo e(asset('assets/vendor/raphael.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/morris.min.js')); ?>"></script>

  <!-- Initialize Charts -->
  <script src="<?php echo e(asset('examples/js/chart.js')); ?>"></script>


  <script>

    function delBanner(ID) {
        var txt;
        var r = confirm("Deseja realmente apagar este Banner?");
        if (r == true) {
        window.location.href="<?php echo e(asset('adm/banner/destroy')); ?>/"+ID;
            alert("Apagado com sucesso!");
        } else {
        txt = "You pressed Cancel!";
        }

    }

    function delDegustacao(ID) {
        var txt;
        var r = confirm("Deseja realmente apagar este Conteúdo?");
        if (r == true) {
        window.location.href="<?php echo e(asset('adm/degustacao/destroy')); ?>/"+ID;
            alert("Apagado Degustação com sucesso!");
        } else {
        txt = "You pressed Cancel!";
        }

    }
    function delDbmnumero(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este Conteúdo?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/dbmnumero/destroy')); ?>/"+ID;
          alert("Apagado DBM Número com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }
    function delDepoimento(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este Conteúdo?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/depoimentos/destroy')); ?>/"+ID;
          alert("Apagado depoimento com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }

    function delGaleria(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este Conteúdo da Galeria?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/galerias/destroy')); ?>/"+ID;
          alert("Apagado conteudo com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }

    function delProfissional(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este profissional?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/profissionais/destroy')); ?>/"+ID;
          alert("Apagado conteudo com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }

    function delDbmcurso(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este conteudo?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/dbmcurso/destroy')); ?>/"+ID;
          alert("Apagado conteudo com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }

    function delCategory(ID){
      var txt;
      var r = confirm("Deseja realmente apagar esta categoria?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/categories/destroy')); ?>/"+ID;
          alert("Apagado conteudo com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }

    function delProfessor(ID){
      var txt;
      var r = confirm("Deseja realmente apagar este professor?");
      if (r == true) {
      window.location.href="<?php echo e(asset('adm/professors/destroy')); ?>/"+ID;
          alert("Apagado conteudo com sucesso!");
      } else {
      txt = "You pressed Cancel!";
      }
    }
  </script>

</body>

</html>

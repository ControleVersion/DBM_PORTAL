<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
  <div class="alert-box success">
  <h2><?php echo Session::get('success'); ?></h2>
  </div>
<?php endif; ?>

 <div class="col-md-6 col-md-offset-1" style="margin-bottom: 400px;">
   <h1> Editar profissional</h1>

   <?php echo Form::model($profissional, [ 'method' => 'PUT','files'=>true,  'class'=>'form-horizontal','route' => ['profissionais.update', $profissional->id ]]); ?>




       <fieldset class="form-group">
           <label for="Descricao"> Título </label>

         <?php echo Form::text('nome', null,['class'=>'form-control','required'=>"", 'id'=>'nome']); ?>


       </fieldset>

       <fieldset class="form-group">
           <label for="Descricao"> Miniatura </label>
           <br>
         <img src="<?php echo e(url('/').'/'.$profissional->foto); ?>" alt="Miniatura" width="300" />
         <?php echo Form::file('image', ['class'=>'form-control-file', 'id'=>'upload']); ?>

         <small class="text-help">Imagem no tamanho 370x370 menor que 250kb.</small>
       </fieldset>


       <fieldset class="form-group">
         <label for="texto_link">Formação / Atuação</label>

         <?php echo Form::text('formacao',null, ['class'=>'form-control', 'id'=>'formacao']); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="descricao">Descrição curta</label>

         <?php echo Form::textarea('descricao',null, ['class'=>'form-control', 'id'=>'descricao']); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Facebook URL</label>

         <?php echo Form::text('facebook',null, ['class'=>'form-control', 'id'=>'facebook']); ?>

       </fieldset>

       <fieldset class="form-group">
         <label for="texto_link">Instagram URL</label>

         <?php echo Form::text('instagram',null, ['class'=>'form-control', 'id'=>'instagram']); ?>

       </fieldset>




       <?php echo Form::submit( 'ATUALIZAR', array('class'=>'btn btn-primary')); ?>

       <a class="btn btn-warning" style="float: right;" st="" href="<?php echo e(asset('adm/profissionais')); ?>" >Voltar</a>

   <?php echo Form::close(); ?>



 </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
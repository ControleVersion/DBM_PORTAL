<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Depoimento extends Model
{
    protected $fillable = ['comentario', 'nome', 'profissao', 'cidade', 'estado'];
}

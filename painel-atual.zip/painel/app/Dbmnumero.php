<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dbmnumero extends Model
{
    protected $fillable = ['icone', 'numero', 'subtitulo'];
}

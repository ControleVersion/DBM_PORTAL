/// mascaras de formulário
//cpf
$("form#newsletter input[name=cpf]").mask("999.999.999-99");

<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT');
header('Content-Type: application/json');

echo '[{
                "id": 1,
                "estado": "rj",
                "nome": "Dra. Margareth Finassen",
                "profissao": "Nutricionista",
                "municipio": "Rio de Janeiro",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 2,
                "estado": "rj",
                "nome": "Dra. Margareth Finassen",
                "profissao": "Neuro",
                "municipio": "Rio de Janeiro",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 3,
                "estado": "rj",
                "nome": "Dra. Carla Chickene",
                "profissao": "Cardiologista",
                "municipio": "Rio de Janeiro",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 4,
                "estado": "sp",
                "nome": "Dra. Elaine Almeida",
                "profissao": "Oftalmologista",
                "municipio": "São Paulo",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 5,
                "estado": "sp",
                "nome": "Dra. Clemilda Eustácia",
                "profissao": "Obstetra",
                "municipio": "São Paulo",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 6,
                "estado": "sp",
                "nome": "Dra. Sivirina Mulestia",
                "profissao": "Pediatra",
                "municipio": "São Paulo",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }, {
                "id": 7,
                "estado": "sp",
                "nome": "Dra. Vilma Potiguar",
                "profissao": "Cirurgiã",
                "municipio": "São Paulo",
                "facebook": "#facebook",
                "twitter": "#margareth",
                "instagran": "#",
                "imagem": "http://kt.comli.com/DBM/images/80x80.jpg"
              }
            ]';

<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVideoaulasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('videoaulas', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('professor_id');
            $table->integer('category_id');
            $table->text('tema');
            $table->string('duracao', 12);
            $table->text('resumo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('videoaulas');
    }
}
